# Shared utility modules
